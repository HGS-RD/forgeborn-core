import React from 'react';
import AgentInterface from './AgentInterface';
import ErrorBoundary from './ErrorBoundary';

const MainContent: React.FC = () => (
  <ErrorBoundary>
    <AgentInterface />
  </ErrorBoundary>
);

export default MainContent;
