import React from 'react';
import AgentForm from './AgentForm';
import ResultDisplay from './ResultDisplay';

const AgentInterface: React.FC = () => (
  <div>
    <AgentForm />
    <ResultDisplay />
  </div>
);

export default AgentInterface;
