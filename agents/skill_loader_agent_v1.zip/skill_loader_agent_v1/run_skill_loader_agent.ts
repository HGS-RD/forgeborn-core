import { SkillLoaderAgent } from './skill_loader_agent.js';

const agent = new SkillLoaderAgent();
const output = agent.runSkillMatch('../../blueprints/factory_generated_rc.yaml', '../../skills/registry.yaml');
console.log('✅ Skill load log written to:', output);