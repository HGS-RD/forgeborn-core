import { readFileSync, writeFileSync, readdirSync } from 'fs';
import { join } from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

console.log("🧠 docs_agent_v1.ts loaded");

export class DocsAgent {
  goal: any;

  constructor(goal: any) {
    console.log("🧠 DocsAgent constructor called with:", goal);
    this.goal = goal;
  }

  generateDocumentation(): string {
    console.log("📄 Reading memory chunks...");
    const memoryDir = join(__dirname, '../../memory/chunks');
    const files = readdirSync(memoryDir);

    const docs = files.map((f) => {
      const content = readFileSync(join(memoryDir, f), 'utf-8');
      return `## ${f.replace('.json', '')}
${content}`;
    }).join('

');

    const outputPath = join(__dirname, '../../docs/forgeborn_core_plan_docs.md');
    writeFileSync(outputPath, `# Forged Plan Documentation

${docs}`);
    console.log("✅ Documentation written to:", outputPath);
    return outputPath;
  }
}
